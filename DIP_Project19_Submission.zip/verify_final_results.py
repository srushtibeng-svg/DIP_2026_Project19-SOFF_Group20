import os
import json
import pandas as pd

ROOT = r"E:\DIP2026\Codes"

files = {
    "OPTICAL ML SUMMARY": os.path.join(
        ROOT, "Optical_ML_Results", "model_comparison_summary.csv"
    ),
    "FARM-WISE METRICS": os.path.join(
        ROOT, "Optical_ML_Results", "farmwise_fold_metrics.csv"
    ),
    "MASTER RESULTS": os.path.join(
        ROOT, "Final_Master_Results", "Master_Results_All_Fields.csv"
    ),
    "SAR TEXTURE SUMMARY": os.path.join(
        ROOT, "Final_Master_Results", "SAR_Optical_Texture_Field_Comparison.csv"
    )
}

for title, path in files.items():
    print("\n==========", title, "==========")
    if os.path.exists(path):
        print(pd.read_csv(path).to_string(index=False))
    else:
        print("FILE NOT FOUND:", path)

info_path = os.path.join(
    ROOT, "Optical_ML_Results", "experiment_info.json"
)
print("\n========== EXPERIMENT INFO ==========")
with open(info_path, "r") as f:
    print(json.dumps(json.load(f), indent=2))

