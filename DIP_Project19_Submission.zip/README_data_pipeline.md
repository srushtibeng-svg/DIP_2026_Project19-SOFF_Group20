# Raw data -> SAR download -> verification (TA's workflow)

1. `python inspect_json.py RAW_DATA/Germany --n 3`   # look at the JSON keys, edit KEYS in build_inventory.py if needed
2. `python build_inventory.py --root RAW_DATA --out ../Results/tables/inventory.csv`   # add --src-epsg 32632 if coordinates are UTM
3. `python download_s1_gee.py --inventory ../Results/tables/inventory.csv --project <gcp-project-id> --out S1_downloads --limit 1`  (then without --limit)
4. `python verify_overlap.py --inventory ../Results/tables/inventory.csv --sar-dir S1_downloads --out ../Results/tables/sar_verification.csv --qgis-dir ../Results/qgis_layers`
5. In QGIS: Layer -> Add Layer -> Add Vector Layer -> `fields.geojson` and `sar_tiles.geojson`; add one S1 .tif as raster; check the footprints overlap.

Co-registration: SAR is exported on the same UTM zone, 10 m pixels and a 10 m-snapped origin (S2 grid convention). Do not commit the .tif files (see .gitignore).
